﻿namespace MusicJuke.Entities
{
    public class Song
    {
        public int SongID { get; set; }
        public string SongName { get; set; }
        public string Movie { get; set; }
        public string ComposedBy { get; set; }
        public int AlbumID { get; set; }
        public string Lyrics { get; set; }
        public int Year { get; set; }
        public string Language { get; set; }
        public string Link { get; set; }
    }
}