﻿ using System;

namespace MusicJuke.Entities
{
    public class Album
    {
        public int AlbumID { get; set; }
        public string AlbumName { get; set; }
        public string Category { get; set; }
        public int NoOfSongs { get; set; }
        public DateTime ReleaseDate { get; set; }
        public string Company { get; set; }
        public decimal Price { get; set; }
        public string Language { get; set; }
    }
}