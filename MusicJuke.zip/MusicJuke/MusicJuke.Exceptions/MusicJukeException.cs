﻿using System;
using System.Runtime.Serialization;

namespace MusicJuke.Exceptions
{
    [Serializable]
    public class MusicJukeException : Exception
    {
        public MusicJukeException()
        {
        }

        public MusicJukeException(string message) : base(message)
        {
        }

        public MusicJukeException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected MusicJukeException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}