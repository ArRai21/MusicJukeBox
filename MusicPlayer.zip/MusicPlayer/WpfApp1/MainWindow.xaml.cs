﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click_add(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            

            //if(con1!=null)
            //{
            //    MessageBox.Show("Pagal anuj)")
            //}

            cmd.CommandText = "tamal.AddEmp";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;

            
            cmd.Parameters.AddWithValue("@ename", textBox.Text);
            cmd.Parameters.AddWithValue("@eid",Convert.ToInt32( textBox_Copy.Text));
            cmd.Parameters.AddWithValue("@addr", textBox_Copy1.Text);
            cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime( textBox_Copy3.Text));
            cmd.Parameters.AddWithValue("@city", textBox_Copy2.Text);
            cmd.Parameters.AddWithValue("@pass", textBox_Copy4.Text);
            cmd.Parameters.AddWithValue("@mobile", textBox1.Text);


            con1.Open();
            cmd.ExecuteNonQuery();
            

        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Grid_Add1.Visibility = Visibility.Visible;
        }

        
    }
}
