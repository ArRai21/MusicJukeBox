﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click_add(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            

            //if(con1!=null)
            //{
            //    MessageBox.Show("Pagal anuj)")
            //}

            cmd.CommandText = "tamal.AddEmp";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;

            
            cmd.Parameters.AddWithValue("@ename", textBox.Text);
            cmd.Parameters.AddWithValue("@eid",Convert.ToInt32( textBox_Copy.Text));
            cmd.Parameters.AddWithValue("@addr", textBox_Copy1.Text);
            cmd.Parameters.AddWithValue("@dob", Date.ToString());
            cmd.Parameters.AddWithValue("@city", textBox_Copy2.Text);
            cmd.Parameters.AddWithValue("@pass", passwordBox.Password.ToString());
            cmd.Parameters.AddWithValue("@mobile", Convert.ToInt32(textBox1.Text));


            con1.Open();
            cmd.ExecuteNonQuery();
            

        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            Grid_Add1.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            con1.Open();
            cmd.CommandText = "tamal.ShowUser";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = null;
            if (dr.HasRows)
            {
               dt = new DataTable();
                dt.Load(dr);
            }
            if (dt != null)
                dataGrid.ItemsSource = dt.DefaultView;

        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            con1.Open();
            cmd.CommandText = "tamal.ShowAlbum";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = null;
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
            }
            if (dt != null)
                dataGrid.ItemsSource = dt.DefaultView;
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            con1.Open();
            cmd.CommandText = "tamal.ShowOrderDetails";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = null;
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
            }
            if (dt != null)
                dataGrid.ItemsSource = dt.DefaultView;
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            textBox2.Visibility = Visibility.Visible;
            button2.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            textBox2.Visibility = Visibility.Visible;
            button5.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            textBox2.Visibility = Visibility.Visible;
            button6.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_7(object sender, RoutedEventArgs e)
        {
            textBox2.Visibility = Visibility.Visible;
            button3.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_8(object sender, RoutedEventArgs e)
        {
            textBox2.Visibility = Visibility.Visible;
            button7.Visibility = Visibility.Visible;
        }

        private void MenuItem_Click_9(object sender, RoutedEventArgs e)
        {
            textBox2.Visibility = Visibility.Visible;
            button8.Visibility = Visibility.Visible;
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            con1.Open();
            cmd.CommandText = "tamal.SearchCust";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@eid", Convert.ToInt32(textBox2.Text));
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = null;
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
            }
            if (dt != null)
                dataGrid.ItemsSource = dt.DefaultView;
        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            con1.Open();
            cmd.CommandText = "tamal.deleteAlbum";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(textBox2.Text));
            cmd.ExecuteNonQuery();
        }

        private void button5_Click(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            con1.Open();
            cmd.CommandText = "tamal.deleteUser";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(textBox2.Text));
            cmd.ExecuteNonQuery();
        }

        private void button6_Click(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            con1.Open();
            cmd.CommandText = "tamal.deleteOrder";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(textBox2.Text));
            cmd.ExecuteNonQuery();
        }

        private void button7_Click(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            con1.Open();
            cmd.CommandText = "tamal.SearchAlbum";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(textBox2.Text));
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = null;
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
            }
            if (dt != null)
                dataGrid.ItemsSource = dt.DefaultView;
        }

        private void button8_Click(object sender, RoutedEventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            string Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
            SqlConnection con1 = new SqlConnection(Con);
            con1.Open();
            cmd.CommandText = "tamal.SearchOrder";
            cmd.Connection = con1;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", Convert.ToInt32(textBox2.Text));
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = null;
            if (dr.HasRows)
            {
                dt = new DataTable();
                dt.Load(dr);
            }
            if (dt != null)
                dataGrid.ItemsSource = dt.DefaultView;
        }
    }
}
